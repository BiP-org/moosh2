<?php
// ********** This file is generated DO NOT EDIT **********
$CFG->siteidentifier = 'PIOEdADKu83uBKOHp8Da0X0H95LYiTZ9localhost';
$CFG->bootstraphash = 'd89748e60c490536039e8b576363be90';
// Only if the file is not stale and has not been defined.
if ($CFG->bootstraphash === hash_local_config_cache() && !defined('SYSCONTEXTID')) {
    define('SYSCONTEXTID', 1);
}
